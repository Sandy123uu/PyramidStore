from spider import Spider, SpiderItemType, SpiderItem, SpiderSubtitle, SpiderSource, SpiderPlayURL
import requests
import re
import urllib
import math
import xbmcaddon
from utils import get_image_path

_ADDON = xbmcaddon.Addon()

base = {
    'ver': '',
    'baseurl': '',
}

class SpiderAlist(Spider):

    def name(self):
        return 'Alist网盘'

    def logo(self):
        return get_image_path('alist.png')

    def is_searchable(self):
        return False

    def hide(self):
        return not _ADDON.getSettingBool('data_source_alist_switch')

    def list_items(self, parent_item=None, page=1):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        if parent_item is None:
            items = []
            #Alist_or_url = 'https://raw.iqiq.io/lm317379829/PyramidStore/pyramid/YSDQ.json'
            Alist_or_url = _ADDON.getSettingString('aliyundrive_refresh_token')
            if Alist_or_url.startswith('http://') or Alist_or_url.startswith('https://'):
                r = requests.get(Alist_or_url)
                data = r.json()
                if 'Alist' in data:
                    for ids in data['Alist']:
                        name = ids
                        id = data['Alist'][ids]
                        items.append(
                            SpiderItem(
                                type=SpiderItemType.Directory,
                                id=id,
                                name=name,
                                params={
                                    'type': 'category',
                                },
                            ))
            else:
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id='https://al.chirmyram.com',
                        name='七米蓝',
                        params={
                            'type': 'category',
                        },
                    ))
            return items, False

        elif parent_item['params']['type'] == 'category':
            if parent_item['id'].endswith('/'):
                category_id = parent_item['id']
            else:
                category_id = parent_item['id'] + '/'
            # get ver start
            if base['ver'] == '' or base['baseurl'] == '':
                baseurl = re.findall(r"http.*://.*?/", category_id)[0]
                ver = requests.get(baseurl + 'api/public/settings')
                vjo = ver.json()['data']
                if type(vjo) is dict:
                    ver = 3
                else:
                    ver = 2
                base['ver'] = ver
                base['baseurl'] = baseurl
            else:
                ver = base['ver']
                baseurl = base['baseurl']
                # get ver end
            pat = category_id.replace(baseurl, "")
            param = {
                "path": '/' + pat
            }
            if ver == 2:
                r = requests.post(baseurl + 'api/public/path', json=param, headers=header)
                data = r.json()['data']['files']
            elif ver == 3:
                r = requests.post(baseurl + 'api/fs/list', json=param, headers=header)
                data = r.json()['data']['content']
            numdata = len(data)
            times = math.ceil(numdata/60)
            numrey = 0
            numvid =0
            items = []
            subtitles = []
            data.sort(key=lambda x: (x['name']), reverse=False)
            for a in range(0, times):
                filename = ''
                for i in range(numrey, numdata):
                    video = data[i]
                    if video['type'] == 1:
                        id = category_id + video['name']
                        items.append(
                            SpiderItem(
                                type=SpiderItemType.Directory,
                                name=video['name'],
                                id=id,
                                params={
                                    'type': 'category',
                                },
                            ))
                    else:
                        if ver == 2:
                            pic = video['thumbnail']
                        elif ver == 3:
                            pic = video['thumb']
                        # 计算文件大小 start
                        size = video['size']
                        if size > 1024 * 1024 * 1024 * 1024.0:
                            fs = "TB"
                            sz = round(size / (1024 * 1024 * 1024 * 1024.0), 2)
                        elif size > 1024 * 1024 * 1024.0:
                            fs = "GB"
                            sz = round(size / (1024 * 1024 * 1024.0), 2)
                        elif size > 1024 * 1024.0:
                            fs = "MB"
                            sz = round(size / (1024 * 1024.0), 2)
                        elif size > 1024.0:
                            fs = "KB"
                            sz = round(size / (1024.0), 2)
                        else:
                            fs = "KB"
                            sz = round(size / (1024.0), 2)
                        # 计算文件大小 end
                        remark = str(sz) + fs
                        endits = video['name'].split('.')[-1]
                        if endits in ['mp4', 'mkv', 'ts', 'TS', 'avi', 'flv', 'rmvb', 'mp3', 'flac', 'wav', 'wma','dff']:
                            filename = filename + '###' + '[{0}]/'.format(remark) + video['name'] + '___' + pic
                            numvid = numvid + 1
                        elif endits in ['srt', 'ass', 'vtt']:
                            subname = video['name']
                            subtitles.append(SpiderSubtitle(subname, 'alist@@@' + category_id + subname))
                    numrey = numrey + 1
                    if numvid % 60 == 0 and numvid !=0:
                        break
                if filename != '':
                    id = category_id + '###' + filename.strip('###')
                    if math.ceil(numvid/60) == 1:
                        name = category_id.strip('/').split('/')[-1]
                    else:
                        st = int((numvid - 1) / 60) + 1
                        name = category_id.strip('/').split('/')[-1] + '-{0}'.format(st)
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Directory,
                            name=name,
                            id=id,
                            subtitles=subtitles,
                            params={
                                'type': 'video',
                            },
                        ))
            return items, False

        elif parent_item['params']['type'] == 'video':
            ids = parent_item['id'].split('###')
            numids = len(ids)
            url = ids[0]
            data = ids[1:numids]
            items = []
            subtitles = parent_item['subtitles']
            for video in data:
                its = video.split('___')
                cover = its[1]
                itms = its[0].split('/')
                sz = itms[0]
                pf = itms[1]
                name = sz + '/' + pf
                items.append(
                    SpiderItem(
                        type=SpiderItemType.File,
                        id=pf,
                        name=name,
                        cover=cover,
                        sources=[
                            SpiderSource(
                                'Alist网盘',
                                {
                                    'url': url,
                                    'id': pf,
                                },
                            )
                        ],
                        subtitles=subtitles,
                    ))

            return items, False
        else:
            return [], False

    def resolve_play_url(self, source_params):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        url = source_params['url']
        # get ver start
        if base['ver'] == '' or base['baseurl'] == '':
            baseurl = re.findall(r"http.*://.*?/", url)[0]
            ver = requests.get(baseurl + 'api/public/settings')
            vjo = ver.json()['data']
            if type(vjo) is dict:
                ver = 3
            else:
                ver = 2
            base['ver'] = ver
            base['baseurl'] = baseurl
        else:
            ver = base['ver']
            baseurl = base['baseurl']
            # get ver end
        pf = source_params['id']
        param = {
            "path": '/' + url.replace(baseurl, '') + urllib.parse.unquote(pf)
        }
        if ver == 2:
            r = requests.post(baseurl + 'api/public/path', json=param, headers=header)
            purl = r.json()['data']['files'][0]['url']
        elif ver == 3:
            r = requests.post(baseurl + 'api/fs/get', json=param, headers=header)
            purl = r.json()['data']['raw_url']
        if purl.startswith('http') is False:
            head = re.findall(r"h.*?:", baseurl)[0]
            purl = head + purl
        return SpiderPlayURL(purl)

    def resolve_subtitles(self, item):
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"}
        url = item.split('@@@')[1]
        # get ver start
        if base['ver'] == '' or base['baseurl'] == '':
            baseurl = re.findall(r"http.*://.*?/", url)[0]
            ver = requests.get(baseurl + 'api/public/settings')
            vjo = ver.json()['data']
            if type(vjo) is dict:
                ver = 3
            else:
                ver = 2
            base['ver'] = ver
            base['baseurl'] = baseurl
        else:
            ver = base['ver']
            baseurl = base['baseurl']
            # get ver end
        param = {
            "path": '/' + url.replace(baseurl, '')
        }
        if ver == 2:
            r = requests.post(baseurl + 'api/public/path', json=param, headers=header)
            suburl = r.json()['data']['files'][0]['url']
        elif ver == 3:
            r = requests.post(baseurl + 'api/fs/get', json=param, headers=header)
            suburl = r.json()['data']['raw_url']
        if suburl.startswith('http') is False:
            head = re.findall(r"h.*?:", baseurl)[0]
            suburl = head + suburl
        return suburl


    def search(self, keyword):
        return []

#if __name__ == '__main__':
    #spider = SpiderAlist()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': 'https://al.chirmyram.com/ani/C/CLANNAD/Season 01', 'name': 'Season 01', 'cover': '', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'category'}}, page=1)
    #res = spider.resolve_play_url({'playfrom': 'youku', 'url': 'https://v.youku.com/v_show/id_XNTg3OTUxNjcyNA==.html'})
    #res = spider.search("红小豆")
    #print(res)