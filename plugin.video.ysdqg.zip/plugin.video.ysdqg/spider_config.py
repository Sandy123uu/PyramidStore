from spider_yingshi import Spideryingshi
from spider_cntv import SpiderCNTV
from spider_bilibili import Spiderbilibili
from spider_zhibo import SpiderZhiBo
from spider_dianshi import SpiderDianShiZhiBo
from spider_ali import SpiderAli
from spider_aliyundrive import SpiderAliyunDrive
from spider_alist import SpiderAlist
from spider_91md import Spider91md


spiders = {
    Spideryingshi.__name__: Spideryingshi(),
    SpiderAli.__name__: SpiderAli(),
    SpiderCNTV.__name__: SpiderCNTV(),
    Spiderbilibili.__name__: Spiderbilibili(),
    SpiderZhiBo.__name__: SpiderZhiBo(),
    SpiderDianShiZhiBo.__name__: SpiderDianShiZhiBo(),
    SpiderAliyunDrive.__name__: SpiderAliyunDrive(),
    SpiderAlist.__name__: SpiderAlist(),
    Spider91md.__name__: Spider91md()
}
