from spider import Spider, SpiderItemType, SpiderSource, SpiderDanmaku, SpiderItem, SpiderPlayURL
from spider_aliyundrive import SpiderAliyunDrive
from proxy import get_proxy_url
from urllib.parse import urlparse
from danmaku import get_danmaku_url
import requests
import hashlib
import time
import re
import json
import base64
import urllib
import difflib
import threading
from bs4 import BeautifulSoup
from utils import get_image_path
import xbmcaddon

_ADDON = xbmcaddon.Addon()

base_params = {
    'pcode': '010110005',
    'version': '2.0.5',
    'devid': hashlib.md5(str(time.time()).encode()).hexdigest(),
    'sys': 'android',
    'sysver': 11,
    'brand': 'google',
    'model': 'Pixel_3_XL',
    'package': 'com.sevenVideo.app.android'
}

base_headers = {
    'User-Agent': 'okhttp/3.12.0',
}

jsonurl = _ADDON.getSettingString('aliyundrive_refresh_token')
jr = requests.get(jsonurl)
jdata = jr.json()

class Spideryingshi(Spider):

    def name(self):
        return '影视'

    def logo(self):
        return get_image_path('yingshi.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_yingshi_switch')

    def is_searchable(self):
        return True

    def list_items(self, parent_item=None, page=1):
        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='豆瓣高分',
                    name='高分电影',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='热门',
                    name='电影',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='剧集',
                    name='剧集',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='综艺',
                    name='综艺',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='日本动画',
                    name='动画',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='纪录片',
                    name='纪录片',
                    params={
                        'type': 'category',
                        'pf': 'db'
                    },
                ))
            return items, False
        elif parent_item['params']['type'] == 'category':
            if parent_item['params']['pf'] == 'db':
                items = []
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
                }
                tag = parent_item['id']
                idname = parent_item['name']
                if '电影' in idname:
                    type = 'movie'
                    url = 'https://movie.douban.com/j/search_subjects?type={}&tag={}&page_limit=50&page_start={}'.format(type, tag, (page - 1) * 50)
                    r = requests.get(url, headers=header)
                    data = json.loads(r.text)['subjects']
                elif tag == '剧集':
                    type = 'tv'
                    ysobjList = []
                    data = []
                    sthnum = len(threading.enumerate())
                    for tag in ['国产剧', '美剧', '日剧', '韩剧']:
                        url = 'https://movie.douban.com/j/search_subjects?type={}&tag={}&page_limit=50&page_start={}'.format(type, tag, (page - 1) * 50)
                        db = threading.Thread(target=self.getData, args=(url, header, '', tag))
                        db.start()
                        ysobjList.append(db)
                    for yL in ysobjList:
                        yL.join(timeout=1)
                    self.thend = True
                    ethnum = len(threading.enumerate())
                    while not ethnum == sthnum:
                        ethnum = len(threading.enumerate())
                    for dL in self.dataList:
                        data = data + json.loads(self.dataList[dL])['subjects']
                        data.sort(key=lambda i: i['is_new'], reverse=True)
                else:
                    type = 'movie'
                    url = 'https://movie.douban.com/j/search_subjects?type={}&tag={}&page_limit=50&page_start={}'.format(type, tag, (page - 1) * 50)
                    r = requests.get(url, headers=header)
                    data = json.loads(r.text)['subjects']
                for video in data:
                    vid = video['id']
                    cover = video['cover']
                    name = video['title'].strip()
                    if '电影' in idname:
                        remark = video['rate']
                        if remark != '':
                            remark = '豆瓣评分：{}分'.format(remark)
                        else:
                            remark = '完结'
                    else:
                        remark = video['episodes_info']
                        if remark == '':
                            remark = '完结'
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.Search,
                            name='[{0}]/{1}'.format(remark, name),
                            id=vid,
                            cover=cover,
                            params={
                                'pf': 'db'
                            },
                        ))
                if page < 10:
                    has_next_page = True
                else:
                    has_next_page = False
            else:
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            return items, has_next_page
        elif parent_item['params']['type'] == 'video':
            if parent_item['params']['pf'] == 'qq':
                ts = int(time.time())
                params = base_params.copy()
                params['ids'] = parent_item['id']
                params['sj'] = ts
                headers = base_headers.copy()
                headers['t'] = str(ts)
                url = 'http://api.kunyu77.com/api.php/provide/videoDetail'
                headers['TK'] = self._get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers)
                detail = r.json()['data']
                url = 'http://api.kunyu77.com/api.php/provide/videoPlaylist'
                headers['TK'] = self._get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers)
                episodes = r.json()['data']['episodes']
                items = []
                for episode in episodes:
                    sources = []
                    danmakus = []
                    for playurl in episode['playurls']:
                        sources.append(
                            SpiderSource(
                                playurl['playfrom'],
                                {
                                    'playfrom': playurl['playfrom'],
                                    'url': playurl['playurl'],
                                    'pf': 'qq'
                                },
                            ))

                        if playurl['playfrom'] in [
                            'qq', 'mgtv', 'qiyi', 'youku', 'bilibili'
                        ]:
                            danmakus.append(
                                SpiderDanmaku(
                                    playurl['playfrom'],
                                    get_danmaku_url(playurl['playurl']),
                                )
                            )
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=episode['title'].strip(),
                            cover=detail['videoCover'],
                            description=detail['brief'].replace('\u3000', '').replace('<p>', '').replace('</p>','').strip(),
                            cast=detail['actor'].replace(' ', '').split('/'),
                            director=detail['director'],
                            area=detail['area'].strip(),
                            year=int(detail['year'].strip()),
                            sources=sources,
                            danmakus=danmakus,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'bw':
                items = []
                url = 'https://beiwo360.com{}'.format(parent_item['id'])
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                    "Referer": 'https://beiwo360.com/'
                }
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                desc = soup.select('div.col-pd.text-collapse.content > span.data')[0].get_text().strip().replace('\u3000\u3000', '\n')
                infos = soup.select('div.myui-content__detail > p.data')
                for info in infos:
                    content = info.get_text()
                    if content.startswith('导演'):
                        dire = content.strip()[3:].strip('\xa0')
                    if content.startswith('主演'):
                        cast = content.strip()[3:].strip('\xa0').split('\xa0')
                    if content.startswith('分类'):
                        area = content.strip().split('：')[2][:-2]
                        year = content.strip().split('：')[3]
                episinfos = soup.select('div.tab-pane.fade.in.clearfix > ul')
                numepis = []
                episList = []
                titleInfos = []
                titleList = re.findall(r'<a href=\"#playlist\d\" data-toggle=\"tab\">(.*?)</a>',r.text)
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.select('li'))
                    numepis.append(lennp)
                    episList.append(episinfo.select('li'))
                    titleInfos.append([lennp, titleList[i].strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: (i)[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.select('a')[0].get_text().strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i]
                        sname = sepisode.select('a')[0].get_text().strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            ratio = difflib.SequenceMatcher(None, name, sname).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            if b < 0:
                                b = 0
                            continue
                        purl = sepisode.select('a')[0].get('href')
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'bw',
                                    'url': purl,
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            area=area,
                            year=int(year),
                            sources=sources,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'ik':
                items = []
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
                }
                url = 'https://ikan6.vip/voddetail/{0}/'.format(parent_item['id'])
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                infos = soup.select('div.myui-content__detail > p.data')
                yainfo = infos[0].get_text().replace('\n\n', '\n').replace('\t', '').strip('\n').split('\n')
                year = int(yainfo[2].replace('年份：', ''))
                area = yainfo[1].replace('地区：', '')
                cast = infos[2].get_text().replace('主演：', '').strip('\xa0').split('\xa0')
                dire = infos[3].get_text().replace('导演：', '').strip('\xa0')
                desc = soup.select('div.col-pd.text-collapse.content > span.data')[0].get_text().replace('\n', '').replace('\u3000', '').replace('：', '').replace('详情', '').replace('\xa0', '').replace(' ', '')
                episinfos = soup.select('div.tab-content.myui-panel_bd > div')
                numepis = []
                episList = []
                titleInfos = []
                titleList = re.findall(r'<a href=\"#playlist\d\" data-toggle=\"tab\">(.*?)</a>',r.text)
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.select('ul > li'))
                    numepis.append(lennp)
                    episList.append(episinfo.select('ul > li'))
                    titleInfos.append([lennp, titleList[i].strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: (i)[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.select('a')[0].get_text().strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i][1]
                        sname = sepisode.select('a')[0].get_text().strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            ratio = difflib.SequenceMatcher(None, name, sname).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            continue
                        purl = re.search(r'/vodplay/(.*?)/', sepisode.select('a')[0].get('href')).group(1)
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'ik',
                                    'url': purl,
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            area=area,
                            year=int(year),
                            sources=sources,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'ld':
                items = []
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
                }
                url = 'https://ldtv.top/index.php/vod/detail/id/{}.html'.format(parent_item['id'])
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                infos = soup.select('div.module-info-items > div')
                cast = infos[2].get_text().replace('主演：', '').strip('\n').strip(' ').strip('/').split('/')
                dire = infos[1].get_text().replace('导演：', '').strip('\n').strip(' ').strip('/')
                desc = infos[0].get_text().strip('\n').replace('　　','\n').strip()
                episinfos = soup.select('div.module > div.module-list')
                numepis = []
                episList = []
                titleInfos = []
                titleList = soup.select('div.module-tab-items-box.hisSwiper > div > span')
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.select('div.module-play-list-content > a'))
                    numepis.append(lennp)
                    episList.append(episinfo.select('div.module-play-list-content > a'))
                    titleInfos.append([lennp, titleList[i].get_text().strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: (i)[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.select('span')[0].get_text().strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i][1]
                        sname = sepisode.select('span')[0].get_text().strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            ratio = difflib.SequenceMatcher(None, name, sname).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            if b < -1:
                                b = -1
                            continue
                        purl = sepisode.get('href')
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'ld',
                                    'url': purl,
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            sources=sources,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'ps':
                if not parent_item['id'].startswith('http'):
                    header = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
                        'Referer': 'https://www.alipansou.com' + '/s/' + parent_item['id']
                    }
                    r = requests.get('https://www.alipansou.com' + '/cv/' + parent_item['id'], allow_redirects=False, headers=header)
                    url = re.search(r'href=\"(.*)\"', r.text).group(1)
                    parent_item['id'] = url
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            if parent_item['params']['pf'] == 'ys' or parent_item['params']['pf'] == 'xzt':
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            if parent_item['params']['pf'] == 'zzy':
                regex_url = re.compile(r'https://www.aliyundrive.com/s/[^"]+')
                if not 'zzy' in self.ckList:
                    self.getCookie('zzy')
                    zzycookie = self.ckList['zzy']
                r = requests.get('https://zhaoziyuan.la/' + parent_item['id'], cookies=zzycookie)
                m = regex_url.search(r.text)
                url = m.group().replace('\\', '')
                parent_item['id'] = url
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
            if parent_item['params']['pf'] == 'ali':
                return SpiderAliyunDrive.list_items(SpiderAliyunDrive(), parent_item, page)
        else:
            return [], False

    def resolve_play_url(self, source_params):
        purl = ''
        if source_params['pf'] == 'qq':
            url = source_params['url']
            headers = {}
            if source_params['playfrom'] != 'ppayun':
                if 'QiQi' in jdata:
                    jxinfos = jdata['QiQi']
                    for jxinfo in jxinfos:
                        jx = jxinfo['jx']
                        jxfrom = jxinfo['jxfrom']
                        gs = jxinfo['gs'].strip().split(',')
                        erro = jxinfo['erro']
                        jurl = jx + url
                        r = requests.get(jurl)
                        if erro in r.text and erro != '':
                            break
                        url = r.json()
                        for i in range(0, len(gs)):
                            url = url[gs[i]]
                        if url == '':
                            break
                        if jxfrom == 'QiQi':
                            return SpiderPlayURL(
                                get_proxy_url(
                                    Spideryingshi.__name__,
                                    self.proxy_m3u8.__name__,
                                    {
                                        'url': url,
                                        'headers': headers
                                    },
                                ))
                        else:
                            return SpiderPlayURL(url)
                else:
                    url = ''
                    return SpiderPlayURL(url)
            else:
                return SpiderPlayURL(
                    get_proxy_url(
                        Spideryingshi.__name__,
                        self.proxy_m3u8.__name__,
                        {
                            'url': url,
                            'headers': headers
                        },
                    ))
        if source_params['pf'] == 'ik':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                "Referer": "https://ikan6.vip/"
            }
            url = 'https://ikan6.vip/vodplay/{0}/'.format(source_params['url'])
            r = requests.get(url, headers=header)
            cookie = r.cookies
            info = json.loads(re.search(r'var player_data=(.*?)</script>', r.text).group(1))
            string = info['url'][8:len(info['url'])]
            substr = base64.b64decode(string).decode('UTF-8')
            str = substr[8:len(substr) - 8]
            if 'Ali' in info['from']:
                url = 'https://cms.ikan6.vip/ali/nidasicaibudaowozaina/nicaibudaowozaina.php?url={0}'.format(str)
            else:
                url = 'https://cms.ikan6.vip/nidasicaibudaowozaina/nicaibudaowozaina.php?url={0}'.format(str)
            r = requests.get(url, headers=header, cookies=cookie)
            randomurl = re.search(r"getrandom\(\'(.*?)\'", r.text).group(1)
            pstring = randomurl[8:len(randomurl)]
            psubstr = base64.b64decode(pstring).decode('UTF-8')
            purl = urllib.parse.unquote(psubstr[8:len(psubstr) - 8])
            pheader = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            if 'Ali' in info['from']:
                return SpiderPlayURL(purl)
            else:
                return SpiderPlayURL(get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__, {'url': purl, 'headers': pheader}))
        if source_params['pf'] == 'bw':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                "Referer": "https://beiwo360.com/"
            }
            url = 'https://beiwo360.com/{0}'.format(source_params['url'])
            r = requests.get(url, headers=header)
            jo = json.loads(re.search(r'var player_aaaa=({.*?)</script>', r.text).group(1))
            purl = jo['url']
            return SpiderPlayURL(purl)
        if source_params['pf'] == 'ld':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            url = 'https://ldtv.top{0}'.format(source_params['url'])
            r = requests.get(url, headers=header)
            jo = json.loads(re.search(r'var player_aaaa=({.*?)</script>', r.text).group(1))
            if jo['from'] in ['qq','youku','qiyi','mgtv','bilibili']:
                url = 'https://ldtv.top/addons/dp/player/dp.php?key=0&from=&id={0}&api=&url={1}'.format(jo['id'], jo['url'])
                r = requests.get(url, headers=header)
                purl = re.search(r'url\": \"(.*?)\"', r.text)
                if not purl is None:
                    purl = purl.group(1)
                else:
                    purl = ''
            elif jo['from'] == 'rx':
                url = 'https://ldtv.top/addons/dp/player/dp.php?key=0&from={}&id={}&api=&url={}&jump='.format(jo['from'], jo['id'], jo['url'])
                r = requests.get(url, headers=header)
                purl = re.search(r'url\": \"(.*?)\"', r.text)
                if not purl is None:
                    purl = purl.group(1)
                else:
                    purl = ''
            else:
                url = 'https://ldtv.top/addons/dp/player/dp.php?key=0&from={}{}&id={}&api=&url={}&jump='.format(jo['from'],jo['from'],jo['id'],jo['url'])
                r = requests.get(url, headers=header)
                purl = re.search(r'url\": \"(.*?)\"', r.text)
                if not purl is None:
                    purl = purl.group(1)
                else:
                    purl = ''
            if 'rongxing' in purl or 'rdxnnnnnnnn' in purl:
                r = requests.get(purl, headers=header, allow_redirects=False)
                purl = r.headers['Location']
            if jo['from'] == 'BYGA' or jo['from'] == 'RRYS':
                purl = purl + '@@@False'
            if jo['from'] == 'qq' or jo['from'] == 'QMYZ' or jo['from'] == 'ffm3u8':
                return SpiderPlayURL(purl)
            else:
                return SpiderPlayURL(get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__,{'url': purl, 'headers': header }))
        if source_params['pf'] == 'ali':
            return SpiderAliyunDrive.resolve_play_url(SpiderAliyunDrive(), source_params)
        return SpiderPlayURL(purl)

    dataList = {}
    def getData(self, url, header, cookie, tag):
        r = requests.get(url, headers=header, cookies=cookie)
        self.dataList.update({tag: r.text})

    thend = False
    searchList = {}
    def search(self, keyword):
        if 'YSDQ' in jdata:
            if 'thlimit' in jdata['YSDQ']:
                self.thlimit = jdata['YSDQ']['thlimit']
        else:
            self.thlimit = 1
        sws = ['qq', 'ik', 'bw', 'ld', 'ps', 'ys', 'zzy', 'xzt']
        ysobjList = []
        items = []
        sthnum = len(threading.enumerate())
        keyword = keyword.replace('/', '%2F')
        for sw in sws:
            if sw == 'qq':
                qq = threading.Thread(target=self.searchqq, args=(keyword, sw))
                qq.start()
                ysobjList.append(qq)
            if sw == 'ik':
                ik = threading.Thread(target=self.searchik, args=(keyword, sw))
                ik.start()
                ysobjList.append(ik)
            if sw == 'bw':
                bw = threading.Thread(target=self.searchbw, args=(keyword, sw))
                bw.start()
                ysobjList.append(bw)
            if sw == 'ld':
                ld = threading.Thread(target=self.searchld, args=(keyword, sw))
                ld.start()
                ysobjList.append(ld)
            if sw == 'ps':
                ps = threading.Thread(target=self.searchps, args=(keyword, sw))
                ps.start()
                ysobjList.append(ps)
            if sw == 'ys':
                ys = threading.Thread(target=self.searchys, args=(keyword, sw))
                ys.start()
                ysobjList.append(ys)
            if sw == 'zzy':
                zzy = threading.Thread(target=self.searchzzy, args=(keyword, sw))
                zzy.start()
                ysobjList.append(zzy)
            if sw == 'xzt':
                xzt = threading.Thread(target=self.searchxzt, args=(keyword, sw))
                xzt.start()
                ysobjList.append(xzt)
        for yL in ysobjList:
            yL.join(timeout=1)
        self.thend = True
        ethnum = len(threading.enumerate())
        while not ethnum == sthnum:
            ethnum = len(threading.enumerate())
        for sL in self.searchList:
            items = items + self.searchList[sL]
        items.sort(key=lambda i: (i)['params']['num'], reverse=False)
        return items

    def searchqq(self, keyword, tag):
        keyword = keyword.replace('/', '%2F')
        url = 'http://api.kunyu77.com/api.php/provide/searchVideo'
        ts = int(time.time())
        params = base_params.copy()
        params['sj'] = ts
        params['searchName'] = keyword
        params['pg'] = 1
        headers = base_headers.copy()
        headers['t'] = str(ts)
        headers['TK'] = self._get_tk(url, params, ts)
        r = requests.get(url, params=params, headers=headers)
        data = r.json()
        qqitems = []
        for video in data['data']:
            remark = video['msg'].strip()
            if remark == '':
                remark = 'HD'
            qqitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='七七：[{0}]/{1}'.format(remark.strip(), video['videoName'].strip()),
                    id=video['id'],
                    cover=video['videoCover'],
                    description=video['brief'].replace('<p>', '').replace('</p>','').strip(),
                    cast=video['starName'].replace(' ','').split(','),
                    year=int(video['year']),
                    params={
                        'type': 'video',
                        'pf': 'qq',
                        'num': 1
                    },
                ))
        self.searchList.update({tag: qqitems})

    def searchik(self, keyword, tag):
        keyword = keyword.replace('/', '%2F')
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        url = 'https://ikan6.vip/vodsearch/-------------/?wd={0}&submit='.format(keyword)
        session = self.verifyCode('https://ikan6.vip/index.php/verify/index.html?', 'https://ikan6.vip/index.php/ajax/verify_check?type=search&verify=')
        r = session.get(url, headers=header)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul#searchList > li')
        ikitems = []
        for video in data:
            sid = re.search(r'/voddetail/(.*?)/', video.find('a').get('href')).group(1)
            name = video.find('h4').get_text().strip()
            year = int(video.select('div.detail > p')[2].get_text().split('年份：')[1])
            description = video.select('div.detail > p')[3].get_text().replace('简介：', '').replace('详情 >', '')
            cover = video.select('div.thumb > a')[0].get('data-original')
            remark = video.select('div.thumb > a')[0].get_text().strip().strip('\n').split('\n')[-1].strip()
            ikitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='爱看：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=description,
                    year=int(year),
                    params={
                        'type': 'video',
                        'pf': 'ik',
                        'num': 2
                    },
                ))
        self.searchList.update({tag: ikitems})

    def searchbw(self, keyword, tag):
        bwitems = []
        keyword = keyword.replace('/', '%2F')
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
            "Referer": "https://beiwo360.com/"
        }
        page = 1
        url = 'https://beiwo360.com/bws/{}----------{}---/'.format(keyword, page)
        r = requests.get(url,headers=header)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul.myui-vodlist__media.clearfix > li.clearfix')
        mpg = soup.select('li.visible-xs > a.btn.btn-warm')
        bwsthnum = len(threading.enumerate())
        if mpg != []:
            maxpage = int(mpg[0].get_text().replace('\xa0', '').strip().split('/')[-1])
        else:
            maxpage = 1
        bwobjList = []
        for page in range(2, maxpage + 1):
            if self.thend is True:
                break
            url = 'https://beiwo360.com/bws/-------------/?wd={}&page={}'.format(keyword, page)
            bwrunthnum = len(threading.enumerate()) - bwsthnum
            while bwrunthnum >= self.thlimit:
                if self.thend is True:
                    break
                bwrunthnum = len(threading.enumerate()) - bwsthnum
            strpage = str(page)
            while len(strpage) < len(str(maxpage)):
                strpage = '0' + strpage
            bwinfo = threading.Thread(target=self.getData, args=(url, header, '', tag+strpage))
            bwinfo.start()
            bwobjList.append(bwinfo)
        for bwL in bwobjList:
            bwL.join(timeout=1)
        bwethnum = len(threading.enumerate())
        while not bwethnum == bwsthnum:
            if self.thend is True:
                break
            bwethnum = len(threading.enumerate())
        for bwdL in list(self.dataList.keys()):
            if not bwdL.startswith('bw'):
                continue
            soup = BeautifulSoup(self.dataList[bwdL], 'html.parser')
            data = data + soup.select('ul.myui-vodlist__media.clearfix > li.clearfix')
        for video in data:
            sid = video.select('div.thumb > a')[0].get('href')
            remark = video.select('div.thumb > a > span.pic-text.text-right')[0].get_text().strip().replace(' ','|')
            name = video.select('div.thumb > a')[0].get('title').strip()
            cover = video.select('div.thumb > a')[0].get('data-original')
            desc = video.select('div.detail > p.hidden-xs')[0].get_text().replace('简介：','').replace('详情 >','').strip()
            bwitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='被窝：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=desc,
                    params={
                        'type': 'video',
                        'pf': 'bw',
                        'num': 3
                    },
                ))
        self.searchList.update({tag: bwitems})

    def searchld(self, keyword, tag):
        page = 1
        keyword = keyword.replace('/','%2F')
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        url = 'https://ldtv.top/index.php/vod/search.html?wd={}&page={}'.format(keyword, page)
        session = self.verifyCode('https://ldtv.top/index.php/verify/index.html?', 'https://ldtv.top/index.php/ajax/verify_check?type=search&verify=')
        r = session.get(url, headers=header)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('div.module-items.module-card-items > div')
        mpg = soup.select('div#page > a')
        cookie = session.cookies
        ldsthnum = len(threading.enumerate())
        if mpg != []:
            maxpage = int(re.search(r'page/(.*?)/', mpg[-1].get('href')).group(1))
        else:
            maxpage = 1
        ldobjList = []
        for page in range(2, maxpage+1):
            if self.thend is True:
                break
            url = 'https://ldtv.top/index.php/vod/search.html?wd={}&page={}'.format(keyword, page)
            ldrunthnum = len(threading.enumerate()) - ldsthnum
            while ldrunthnum >= self.thlimit:
                if self.thend is True:
                    break
                ldrunthnum = len(threading.enumerate()) - ldsthnum
            strpage = str(page)
            while len(strpage) < len(str(maxpage)):
                strpage = '0' + strpage
            ldinfo = threading.Thread(target=self.getData, args=(url, header, cookie, tag+strpage))
            ldinfo.start()
            ldobjList.append(ldinfo)
        for ldL in ldobjList:
            ldL.join(timeout=1)
        ldethnum = len(threading.enumerate())
        while not ldethnum == ldsthnum:
            ldethnum = len(threading.enumerate())
        for lddL in list(self.dataList.keys()):
            if not lddL.startswith('ld'):
                continue
            soup = BeautifulSoup(self.dataList[lddL], 'html.parser')
            data = data + soup.select('div.module-items.module-card-items > div')
        lditems = []
        for video in data:
            sid = re.search(r'/id/(.*?).html', video.find('a').get('href')).group(1)
            name = video.select('div.module-card-item-title')[0].get_text().strip()
            description = video.select('div.module-info-item-content')[1].get_text().strip().replace('　　','\n')
            cover = video.select('div.module-item-pic > img')[0].get('data-original')
            remark = video.select('div.module-item-note')[0].get_text().strip()
            lditems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='零度：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=description,
                    params={
                        'type': 'video',
                        'pf': 'ld'
                        ,
                        'num': 4
                    },
                ))
        self.searchList.update({tag: lditems})

    def searchps(self, keyword, tag):
        psitems = []
        r = requests.get('https://www.alipansou.com/search', params={'k': keyword, 't': 7})
        soup = BeautifulSoup(r.text, 'html.parser')
        rows = soup.select('van-row > a')
        for row in rows:
            remark = re.search(r'时间: (.*?) ', str(row.get_text)).group(1)
            clean = re.compile('<.*?>')
            name = re.sub(clean, '', row.find('template').__str__()).replace('\n', '').replace('\t', '').replace(' ', '')
            psitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='盘搜：[{0}]/{1}'.format(remark, name),
                    id=re.search(r'/s/(.*)', row.get('href')).group(1),
                    params={
                        'type': 'video',
                        'pf': 'ps',
                        'num': 5
                    }
                ))
        self.searchList.update({tag: psitems})

    def searchys(self, keyword, tag):
        ysitems = []
        header = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 12; V2049A Build/SP1A.210812.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36",
            "Referer": "https://yiso.fun/"
        }
        url = "https://yiso.fun/api/search?name={0}&from=ali".format(keyword)
        elements = requests.get(url=url, headers=header).json()["data"]["list"]
        for element in elements:
            id = element["url"]
            name = element["fileInfos"][0]["fileName"]
            remark = element['gmtCreate'].split(' ')[0]
            ysitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id=id,
                    name='易搜：[{0}]/{1}'.format(remark, name),
                    params={
                        'type': 'video',
                        'pf': 'ys',
                        'num': 6
                    }
                ))
        self.searchList.update({tag: ysitems})

    def searchxzt(self, keyword, tag):
        xztitems = []
        r = requests.post('https://gitcafe.net/tool/alipaper/', data={'action': 'search', 'keyword': keyword})
        data = r.json()
        for video in data:
            xztitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='https://www.aliyundrive.com/s/' + video['key'],
                    name='小纸条：' + video['title'],
                    params={
                        'type': 'video',
                        'pf': 'xzt',
                        'num': 8
                    }
                ))
        self.searchList.update({tag: xztitems})

    def searchzzy(self, keyword, tag):
        zzyitems = []
        if not 'zzy' in self.ckList:
            self.getCookie('zzy')
            zzycookie = self.ckList['zzy']
        r = requests.get('https://zhaoziyuan.la/so', params={'filename': keyword}, cookies=zzycookie)
        soup = BeautifulSoup(r.text, 'html.parser')
        elements = soup.select('div.news_text > a')
        for element in elements:
            name = element.find('h3').text
            if name is None:
                return []
            else:
                remark = element.find('p').text.split('|')[-1].split('：')[1].split(' ')[0].strip()
                zzyitems.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        id=element.get('href'),
                        name='找资源：[{0}]/{1}'.format(remark, name),
                        params={
                            'type': 'video',
                            'pf': 'zzy',
                            'num': 7
                        }
                    ))
        self.searchList.update({tag: zzyitems})

    ckList = {}
    def getCookie(self, tag):
        if tag == 'zzy':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36",
                "Referer": "https://zhaoziyuan.la/login.html",
                "Origin": "https://zhaoziyuan.la/"
            }
            if 'Zhaozy' in jdata:
                logininfo = {'username': jdata['Zhaozy']['username'], 'password': jdata['Zhaozy']['password']}
                r = requests.post('https://zhaoziyuan.la/logiu.html', data=logininfo, headers=header)
                ckDict = {tag: r.cookies}
                self.ckList.update(ckDict)

    def verifyCode(self, imgurl, resurl):
        if 'YSDQ' in jdata:
            if 'ocrurl' in jdata['YSDQ']:
                ocrurl = jdata['YSDQ']['ocrurl']
        else:
            ocrurl = ''
        retry = 10
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"
        }
        while retry:
            try:
                session = requests.session()
                img = session.get(imgurl, headers=header).content
                code = session.post(url=ocrurl, data=base64.b64encode(img).decode()).text
                res = session.post(url="{}{}".format(resurl, code), headers=header).json()
                if res["msg"] == "ok":
                    return session
                if self.thend is True:
                    break
            except Exception as e:
                print(e)
            finally:
                retry = retry - 1

    def _get_tk(self, url, params, ts):
        keys = []
        for key in params:
            keys.append(key)
        keys.sort()
        src = urlparse(url).path
        for key in keys:
            src += str(params[key])
        src += str(ts)
        src += 'XSpeUFjJ'
        return hashlib.md5(src.encode()).hexdigest()

    def proxy_m3u8(self, ctx, params):
        url = params['url']
        redirects = ''
        if '@@@' in url:
            infos = url.split('@@@')
            url = infos[0]
            redirects = infos[1]
        headers = params['headers'].copy()
        if redirects == 'False':
            r = requests.get(url, headers=headers, stream=True, verify=False, allow_redirects=False)
        else:
            r = requests.get(url, headers=headers, stream=True, verify=False)
        content_type = r.headers['Content-Type'] if 'Content-Type' in r.headers else ''
        if content_type.startswith('image/') or content_type.startswith('text/'):
            content_type = 'application/vnd.apple.mpegurl'
        r.headers['Content-Type'] = content_type
        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in ['connection', 'transfer-encoding']:
                    continue
                if content_type.lower() == 'application/vnd.apple.mpegurl':
                    if key.lower() in ['content-length', 'content-range']:
                        continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()
            if content_type.lower() == 'application/vnd.apple.mpegurl':
                for line in r.iter_lines(8192):
                    line = line.decode()
                    if len(line) > 0 and not line.startswith('#'):
                        if not line.startswith('http'):
                            if line.startswith('/'):
                                line = url[:url.index('/', 8)] + line
                            else:
                                line = url[:url.rindex('/') + 1] + line
                        line = get_proxy_url(
                            Spideryingshi.__name__,
                            self.proxy_ts.__name__,
                            {
                                'url': line,
                                'headers': params['headers'],
                            },
                        )
                    ctx.wfile.write((line + '\n').encode())
            else:
                for chunk in r.iter_content(8192):
                    ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

    def proxy_ts(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        for key in ctx.headers:
            if key.lower() in ['user-agent', 'host']:
                continue
            headers[key] = ctx.headers[key]
        r = requests.get(url, headers=headers, stream=True, verify=False)
        r.headers['Content-Type'] = 'video/MP2T'

        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in ['connection', 'transfer-encoding', 'accept-ranges']:
                    continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()
            stripped_image_header = False
            for chunk in r.iter_content(8192):
                if not stripped_image_header:
                    chunk = chunk.lstrip(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46')
                    chunk = chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
                    chunk = chunk.lstrip(b'\x42\x4D\x5A\x27\x4C')
                    chunk = chunk.lstrip(b'\x42\x4D')
                    stripped_image_header = True
                ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

#if __name__ == '__main__':
    #spider = Spideryingshi()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': 'https://www.aliyundrive.com/s/eBXoombeciC/folder/63b2a45fa6b44e1d8fa742068fb43d824a4ec922', 'name': 'The.Glory.S01.Part.1.KOREAN.2160p.NF.WEB-DL.x265.10bit.HDR.DDP5.1.Atmos-XEBEC', 'cover': 'https://img.aliyundrive.com/avatar/default/02.png', 'description': '', 'cast': [], 'director': '', 'area': '', 'year': 0, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'category', 'pf': 'ali'}}, page=1)
    #res = spider.resolve_play_url({'template_id': 'FHD', 'share_id': 'eBXoombeciC', 'file_id': '63b2a4b5c12ed206267041318cc15f3efb930a14', 'drive_id': '478056041', 'pf': 'ali'})
    #res = spider.search("黑暗荣耀")
    #print(res)