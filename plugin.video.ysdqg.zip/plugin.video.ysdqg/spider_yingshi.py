from spider import Spider, SpiderItemType, SpiderSource, SpiderDanmaku, SpiderItem, SpiderPlayURL
from proxy import get_proxy_url
from urllib.parse import urlparse
from danmaku import get_danmaku_url
import requests
import hashlib
import time
import re
import json
import base64
import urllib
import difflib
import threading
from bs4 import BeautifulSoup
from utils import get_image_path
import xbmcaddon

_ADDON = xbmcaddon.Addon()

base_params = {
    'pcode': '010110005',
    'version': '2.0.5',
    'devid': hashlib.md5(str(time.time()).encode()).hexdigest(),
    'sys': 'android',
    'sysver': 11,
    'brand': 'google',
    'model': 'Pixel_3_XL',
    'package': 'com.sevenVideo.app.android'
}

base_headers = {
    'User-Agent': 'okhttp/3.12.0',
}


class Spideryingshi(Spider):

    def name(self):
        return '影视'

    def logo(self):
        return get_image_path('yingshi.png')

    def hide(self):
        return not _ADDON.getSettingBool('data_source_yingshi_switch')

    def is_searchable(self):
        return True

    def list_items(self, parent_item=None, page=1):

        if parent_item is None:
            items = []
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='dianying',
                    name='电影',
                    params={
                        'type': 'category',
                        'pf': 'bw'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='lianxuju',
                    name='剧集',
                    params={
                        'type': 'category',
                        'pf': 'bw'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='dongman',
                    name='动漫',
                    params={
                        'type': 'category',
                        'pf': 'bw'
                    },
                ))
            items.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    id='zongyi',
                    name='综艺',
                    params={
                        'type': 'category',
                        'pf': 'bw'
                    },
                ))
            return items, False
        elif parent_item['params']['type'] == 'category':
            items = []
            url = 'https://beiwo360.com/bs/{0}/page/{1}/'.format(parent_item['id'],page)
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            r = requests.get(url, headers=header)
            soup = BeautifulSoup(r.text, 'html.parser')
            data = soup.select('ul.myui-vodlist.clearfix > li')
            maxpage = int(soup.select('ul.myui-page.text-center.clearfix > li.visible-xs')[0].get_text().split('/')[-1])
            for video in data:
                vid = video.select('a')[0].get('href')
                cover = video.select('a')[0].get('data-original')
                name = video.select('a')[0].get('title').strip()
                remark = video.select('a > span.pic-text.text-right')[0].get_text().strip().replace(' ','|')
                items.append(
                    SpiderItem(
                        type=SpiderItemType.Directory,
                        name='{0}/[{1}]'.format(name, remark),
                        id=vid,
                        cover=cover,
                        params={
                            'type': 'video',
                            'pf': 'bw'
                        },
                    ))
            if page < maxpage:
                has_next_page = True
            else:
                has_next_page = False
            return items, has_next_page
        elif parent_item['params']['type'] == 'video':
            if parent_item['params']['pf'] == 'qq':
                ts = int(time.time())
                params = base_params.copy()
                params['ids'] = parent_item['id']
                params['sj'] = ts
                headers = base_headers.copy()
                headers['t'] = str(ts)
                url = 'http://api.kunyu77.com/api.php/provide/videoDetail'
                headers['TK'] = self._get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers)
                detail = r.json()['data']
                url = 'http://api.kunyu77.com/api.php/provide/videoPlaylist'
                headers['TK'] = self._get_tk(url, params, ts)
                r = requests.get(url, params=params, headers=headers)
                episodes = r.json()['data']['episodes']
                items = []
                for episode in episodes:
                    sources = []
                    danmakus = []
                    for playurl in episode['playurls']:
                        sources.append(
                            SpiderSource(
                                playurl['playfrom'],
                                {
                                    'playfrom': playurl['playfrom'],
                                    'url': playurl['playurl'],
                                    'pf': 'qq'
                                },
                            ))

                        if playurl['playfrom'] in [
                            'qq', 'mgtv', 'qiyi', 'youku', 'bilibili'
                        ]:
                            danmakus.append(
                                SpiderDanmaku(
                                    playurl['playfrom'],
                                    get_danmaku_url(playurl['playurl']),
                                )
                            )
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=episode['title'].strip(),
                            cover=detail['videoCover'],
                            description=detail['brief'].replace('\u3000', '').replace('<p>', '').replace('</p>','').strip(),
                            cast=detail['actor'].replace(' ', '').split('/'),
                            director=detail['director'],
                            area=detail['area'].strip(),
                            year=int(detail['year'].strip()),
                            sources=sources,
                            danmakus=danmakus,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'bw':
                items = []
                url = 'https://beiwo360.com{}'.format(parent_item['id'])
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                    "Referer": 'https://beiwo360.com/'
                }
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                desc = soup.select('div.col-pd.text-collapse.content > span.data')[0].get_text().strip().replace('\u3000\u3000', '\n')
                infos = soup.select('div.myui-content__detail > p.data')
                for info in infos:
                    content = info.get_text()
                    if content.startswith('导演'):
                        dire = content.strip()[3:].strip('\xa0')
                    if content.startswith('主演'):
                        cast = content.strip()[3:].strip('\xa0').split('\xa0')
                    if content.startswith('分类'):
                        area = content.strip().split('：')[2][:-2]
                        year = content.strip().split('：')[3]
                episinfos = soup.select('div.tab-pane.fade.in.clearfix > ul')
                numepis = []
                episList = []
                titleInfos = []
                titleList = re.findall(r'<a href=\"#playlist\d\" data-toggle=\"tab\">(.*?)</a>',r.text)
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.select('li'))
                    numepis.append(lennp)
                    episList.append(episinfo.select('li'))
                    titleInfos.append([lennp, titleList[i].strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: (i)[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.select('a')[0].get_text().strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i]
                        sname = sepisode.select('a')[0].get_text().strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            ratio = difflib.SequenceMatcher(None, name, sname).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            if b < 0:
                                b = 0
                            continue
                        purl = sepisode.select('a')[0].get('href')
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'bw',
                                    'url': purl,
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            area=area,
                            year=int(year),
                            sources=sources,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'ik':
                items = []
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
                }
                url = 'https://ikan6.vip/voddetail/{0}/'.format(parent_item['id'])
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                infos = soup.select('div.myui-content__detail > p.data')
                yainfo = infos[0].get_text().replace('\n\n', '\n').replace('\t', '').strip('\n').split('\n')
                year = int(yainfo[2].replace('年份：', ''))
                area = yainfo[1].replace('地区：', '')
                cast = infos[2].get_text().replace('主演：', '').strip('\xa0').split('\xa0')
                dire = infos[3].get_text().replace('导演：', '').strip('\xa0')
                desc = soup.select('div.col-pd.text-collapse.content > span.data')[0].get_text().replace('\n', '').replace('\u3000', '').replace('：', '').replace('详情', '').replace('\xa0', '').replace(' ', '')
                episinfos = soup.select('div.tab-content.myui-panel_bd > div')
                numepis = []
                episList = []
                titleInfos = []
                titleList = re.findall(r'<a href=\"#playlist\d\" data-toggle=\"tab\">(.*?)</a>',r.text)
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.select('ul > li'))
                    numepis.append(lennp)
                    episList.append(episinfo.select('ul > li'))
                    titleInfos.append([lennp, titleList[i].strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: (i)[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.select('a')[0].get_text().strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i][1]
                        sname = sepisode.select('a')[0].get_text().strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            ratio = difflib.SequenceMatcher(None, name, sname).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            continue
                        purl = re.search(r'/vodplay/(.*?)/', sepisode.select('a')[0].get('href')).group(1)
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'ik',
                                    'url': purl,
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            area=area,
                            year=int(year),
                            sources=sources,
                        ))
                return items, False
            if parent_item['params']['pf'] == 'ld':
                items = []
                header = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
                }
                url = 'https://ldtv.top/index.php/vod/detail/id/{}.html'.format(parent_item['id'])
                r = requests.get(url, headers=header)
                soup = BeautifulSoup(r.text, 'html.parser')
                cover = parent_item['cover']
                infos = soup.select('div.module-info-items > div')
                cast = infos[2].get_text().replace('主演：', '').strip('\n').strip(' ').strip('/').split('/')
                dire = infos[1].get_text().replace('导演：', '').strip('\n').strip(' ').strip('/')
                desc = infos[0].get_text().strip('\n').replace('　　','\n').strip()
                episinfos = soup.select('div.module > div.module-list')
                numepis = []
                episList = []
                titleInfos = []
                titleList = soup.select('div.module-tab-items-box.hisSwiper > div > span')
                i = 0
                for episinfo in episinfos:
                    lennp = len(episinfo.select('div.module-play-list-content > a'))
                    numepis.append(lennp)
                    episList.append(episinfo.select('div.module-play-list-content > a'))
                    titleInfos.append([lennp, titleList[i].get_text().strip()])
                    i = i + 1
                episList.sort(key=lambda i: len(i), reverse=True)
                titleInfos.sort(key=lambda i: (i)[0], reverse=True)
                maxepis = max(numepis)
                episodes = episList[0]
                a = 0
                b = 0
                for episode in episodes:
                    sources = []
                    i = 0
                    name = episode.select('span')[0].get_text().strip()
                    for epis in episList:
                        if i == 0:
                            k = a
                        else:
                            k = b
                        if k >= len(epis):
                            continue
                        if epis[k] == episode:
                            sepisode = episode
                        else:
                            sepisode = epis[b]
                        title = titleInfos[i][1]
                        sname = sepisode.select('span')[0].get_text().strip()
                        if len(sepisode) == maxepis or '1080P' in sname or 'HD' in sname or '正片' in sname or '国语' in sname or '粤语' in sname or '韩语' in sname or '英语' in sname or '中字' in sname:
                            ratio = 1
                        else:
                            ratio = difflib.SequenceMatcher(None, name, sname).ratio()
                        if ratio < 0.1 or '预告' in sname or '回顾' in sname:
                            b = b - 1
                            if b < -1:
                                b = -1
                            continue
                        purl = sepisode.get('href')
                        sources.append(
                            SpiderSource(
                                title,
                                {
                                    'playfrom': '',
                                    'pf': 'ld',
                                    'url': purl,
                                },
                            ))
                        i = i + 1
                    a = a + 1
                    b = b + 1
                    items.append(
                        SpiderItem(
                            type=SpiderItemType.File,
                            name=name,
                            cover=cover,
                            description=desc,
                            cast=cast,
                            director=dire,
                            sources=sources,
                        ))
                return items, False
        else:
            return [], False

    def resolve_play_url(self, source_params):
        purl = ''
        if source_params['pf'] == 'qq':
            url = source_params['url']
            headers = {}
            if source_params['playfrom'] != 'ppayun':
                jxurl = _ADDON.getSettingString('aliyundrive_refresh_token')
                # jxurl = 'https://raw.iqiq.io/lm317379829/PyramidStore/pyramid/YSDQ.json'
                r = requests.get(jxurl)
                data = r.json()
                if 'QiQi' in data:
                    jxinfos = data['QiQi']
                    for jxinfo in jxinfos:
                        jx = jxinfo['jx']
                        jxfrom = jxinfo['jxfrom']
                        gs = jxinfo['gs'].strip().split(',')
                        erro = jxinfo['erro']
                        jurl = jx + url
                        r = requests.get(jurl)
                        if erro in r.text and erro != '':
                            break
                        url = r.json()
                        for i in range(0, len(gs)):
                            url = url[gs[i]]
                        if url == '':
                            break
                        if jxfrom == 'QiQi':
                            return SpiderPlayURL(
                                get_proxy_url(
                                    Spideryingshi.__name__,
                                    self.proxy_m3u8.__name__,
                                    {
                                        'url': url,
                                        'headers': headers
                                    },
                                ))
                        else:
                            return SpiderPlayURL(url)
                else:
                    url = ''
                    return SpiderPlayURL(url)
            else:
                return SpiderPlayURL(
                    get_proxy_url(
                        Spideryingshi.__name__,
                        self.proxy_m3u8.__name__,
                        {
                            'url': url,
                            'headers': headers
                        },
                    ))
        if source_params['pf'] == 'ik':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                "Referer": "https://ikan6.vip/"
            }
            url = 'https://ikan6.vip/vodplay/{0}/'.format(source_params['url'])
            r = requests.get(url, headers=header)
            cookie = r.cookies
            info = json.loads(re.search(r'var player_data=(.*?)</script>', r.text).group(1))
            string = info['url'][8:len(info['url'])]
            substr = base64.b64decode(string).decode('UTF-8')
            str = substr[8:len(substr) - 8]
            if 'Ali' in info['from']:
                url = 'https://cms.ikan6.vip/ali/nidasicaibudaowozaina/nicaibudaowozaina.php?url={0}'.format(str)
            else:
                url = 'https://cms.ikan6.vip/nidasicaibudaowozaina/nicaibudaowozaina.php?url={0}'.format(str)
            r = requests.get(url, headers=header, cookies=cookie)
            randomurl = re.search(r"getrandom\(\'(.*?)\'", r.text).group(1)
            pstring = randomurl[8:len(randomurl)]
            psubstr = base64.b64decode(pstring).decode('UTF-8')
            purl = urllib.parse.unquote(psubstr[8:len(psubstr) - 8])
            pheader = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            if 'Ali' in info['from']:
                return SpiderPlayURL(purl)
            else:
                return SpiderPlayURL(get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__, {'url': purl, 'headers': pheader}))
        if source_params['pf'] == 'bw':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                "Referer": "https://beiwo360.com/"
            }
            url = 'https://beiwo360.com/{0}'.format(source_params['url'])
            r = requests.get(url, headers=header)
            jo = json.loads(re.search(r'var player_aaaa=({.*?)</script>', r.text).group(1))
            purl = jo['url']
            return SpiderPlayURL(purl)
        if source_params['pf'] == 'ld':
            header = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36"
            }
            url = 'https://ldtv.top{0}'.format(source_params['url'])
            r = requests.get(url, headers=header)
            jo = json.loads(re.search(r'var player_aaaa=({.*?)</script>', r.text).group(1))
            if jo['from'] in ['qq','youku','qiyi','mgtv','bilibili']:
                url = 'https://ldtv.top/addons/dp/player/dp.php?key=0&from=&id={0}&api=&url={1}'.format(jo['id'], jo['url'])
                r = requests.get(url, headers=header)
                purl = re.search(r'url\": \"(.*?)\"', r.text)
                if not purl is None:
                    purl = purl.group(1)
                else:
                    purl = ''
            elif jo['from'] == 'rx':
                url = 'https://ldtv.top/addons/dp/player/dp.php?key=0&from={}&id={}&api=&url={}&jump='.format(jo['from'], jo['id'], jo['url'])
                r = requests.get(url, headers=header)
                purl = re.search(r'url\": \"(.*?)\"', r.text)
                if not purl is None:
                    purl = purl.group(1)
                else:
                    purl = ''
            else:
                url = 'https://ldtv.top/addons/dp/player/dp.php?key=0&from={}{}&id={}&api=&url={}&jump='.format(jo['from'],jo['from'],jo['id'],jo['url'])
                r = requests.get(url, headers=header)
                purl = re.search(r'url\": \"(.*?)\"', r.text)
                if not purl is None:
                    purl = purl.group(1)
                else:
                    purl = ''
            if 'rongxing' in purl or 'rdxnnnnnnnn' in purl:
                r = requests.get(purl, headers=header, allow_redirects=False)
                purl = r.headers['Location']
            if jo['from'] == 'BYGA' or jo['from'] == 'RRYS':
                purl = purl + '@@@False'
            if jo['from'] == 'qq' or jo['from'] == 'QMYZ' or jo['from'] == 'ffm3u8':
                return SpiderPlayURL(purl)
            else:
                return SpiderPlayURL(get_proxy_url(Spideryingshi.__name__, self.proxy_m3u8.__name__,{'url': purl, 'headers': header }))
        return SpiderPlayURL(purl)

    thend = False
    def search(self, keyword):
        sws = ['七七', '爱看', '被窝', '零度']
        ysobj = []
        items = []
        sthnum = len(threading.enumerate())
        keyword = keyword.replace('/', '%2F')
        for sw in sws:
            if sw == '七七':
                qq = threading.Thread(target=self.searchqq, args=(keyword,))
                qq.start()
                ysobj.append(qq)
            if sw == '爱看':
                ik = threading.Thread(target=self.searchik, args=(keyword,))
                ik.start()
                ysobj.append(ik)
            if sw == '被窝':
                bw = threading.Thread(target=self.searchbw, args=(keyword,))
                bw.start()
                ysobj.append(bw)
            if sw == '零度':
                ld = threading.Thread(target=self.searchld, args=(keyword,))
                ld.start()
                ysobj.append(ld)
        for ys in ysobj:
            ys.join(timeout=1)
        self.thend = True
        ethnum = len(threading.enumerate())
        while not ethnum == sthnum:
            ethnum = len(threading.enumerate())
        if hasattr(self, "qqitems") is True:
            items = items + self.qqitems
        if hasattr(self, "ikitems") is True:
            items = items + self.ikitems
        if hasattr(self, "bwitems") is True:
            items = items + self.bwitems
        if hasattr(self, "lditems") is True:
            items = items + self.lditems
        return items

    def searchqq(self, keyword):
        keyword = keyword.replace('/', '%2F')
        url = 'http://api.kunyu77.com/api.php/provide/searchVideo'
        ts = int(time.time())
        params = base_params.copy()
        params['sj'] = ts
        params['searchName'] = keyword
        params['pg'] = 1
        headers = base_headers.copy()
        headers['t'] = str(ts)
        headers['TK'] = self._get_tk(url, params, ts)
        r = requests.get(url, params=params, headers=headers)
        data = r.json()
        qqitems = []
        for video in data['data']:
            remark = video['msg'].strip()
            if remark == '':
                remark = 'HD'
            qqitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='七七：[{0}]/{1}'.format(remark.strip(), video['videoName'].strip()),
                    id=video['id'],
                    cover=video['videoCover'],
                    description=video['brief'].replace('<p>', '').replace('</p>','').strip(),
                    cast=video['starName'].replace(' ','').split(','),
                    year=int(video['year']),
                    params={
                        'type': 'video',
                        'pf': 'qq'
                    },
                ))
        self.qqitems = qqitems

    def searchik(self, keyword):
        keyword = keyword.replace('/', '%2F')
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        url = 'https://ikan6.vip/vodsearch/-------------/?wd={0}&submit='.format(keyword)
        session = self.verifyCode('https://ikan6.vip/index.php/verify/index.html?', 'https://ikan6.vip/index.php/ajax/verify_check?type=search&verify=')
        r = session.get(url, headers=header)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul#searchList > li')
        ikitems = []
        for video in data:
            sid = re.search(r'/voddetail/(.*?)/', video.find('a').get('href')).group(1)
            name = video.find('h4').get_text().strip()
            year = int(video.select('div.detail > p')[2].get_text().split('年份：')[1])
            description = video.select('div.detail > p')[3].get_text().replace('简介：', '').replace('详情 >', '')
            cover = video.select('div.thumb > a')[0].get('data-original')
            remark = video.select('div.thumb > a')[0].get_text().strip().strip('\n').split('\n')[-1].strip()
            ikitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='爱看：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=description,
                    year=int(year),
                    params={
                        'type': 'video',
                        'pf': 'ik'
                    },
                ))
        self.ikitems =ikitems

    def searchbw(self, keyword):
        bwitems = []
        keyword = keyword.replace('/', '%2F')
        header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
            "Referer": "https://beiwo360.com/"
        }
        page = 1
        url = 'https://beiwo360.com/bws/{}----------{}---/'.format(keyword, page)
        r = next(self.getSearch(url, header, ''))
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('ul.myui-vodlist__media.clearfix > li.clearfix')
        mpg = soup.select('li.visible-xs > a.btn.btn-warm')
        if mpg != []:
            maxpage = int(mpg[0].get_text().replace('\xa0', '').strip().split('/')[-1])
        else:
            maxpage = 1
        for page in range(2, maxpage + 1):
            if self.thend is True:
                break
            url = 'https://beiwo360.com/bws/-------------/?wd={}&page={}'.format(keyword, page)
            r = next(self.getSearch(url, header, ''))
            soup = BeautifulSoup(r.text, 'html.parser')
            data = data + soup.select('ul.myui-vodlist__media.clearfix > li.clearfix')
        for video in data:
            sid = video.select('div.thumb > a')[0].get('href')
            remark = video.select('div.thumb > a > span.pic-text.text-right')[0].get_text().strip().replace(' ','|')
            name = video.select('div.thumb > a')[0].get('title').strip()
            cover = video.select('div.thumb > a')[0].get('data-original')
            desc = video.select('div.detail > p.hidden-xs')[0].get_text().replace('简介：','').replace('详情 >','').strip()
            bwitems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='被窝：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=desc,
                    params={
                        'type': 'video',
                        'pf': 'bw'
                    },
                ))
        self.bwitems = bwitems

    def searchld(self, keyword):
        page = 1
        keyword = keyword.replace('/','%2F')
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        url = 'https://ldtv.top/index.php/vod/search.html?wd={}&page={}'.format(keyword, page)
        session = self.verifyCode('https://ldtv.top/index.php/verify/index.html?', 'https://ldtv.top/index.php/ajax/verify_check?type=search&verify=')
        r = session.get(url, headers=header)
        soup = BeautifulSoup(r.text, 'html.parser')
        data = soup.select('div.module-items.module-card-items > div')
        mpg = soup.select('div#page > a')
        cookie = session.cookies
        if mpg != []:
            maxpage = int(re.search(r'page/(.*?)/', mpg[-1].get('href')).group(1))
        else:
            maxpage = 1
        for page in range(2, maxpage+1):
            if self.thend is True:
                break
            url = 'https://ldtv.top/index.php/vod/search.html?wd={}&page={}'.format(keyword, page)
            r = next(self.getSearch(url, header, cookie))
            soup = BeautifulSoup(r.text, 'html.parser')
            data = data + soup.select('div.module-items.module-card-items > div')
        lditems = []
        for video in data:
            sid = re.search(r'/id/(.*?).html', video.find('a').get('href')).group(1)
            name = video.select('div.module-card-item-title')[0].get_text().strip()
            description = video.select('div.module-info-item-content')[1].get_text().strip().replace('　　','\n')
            cover = video.select('div.module-item-pic > img')[0].get('data-original')
            remark = video.select('div.module-item-note')[0].get_text().strip()
            lditems.append(
                SpiderItem(
                    type=SpiderItemType.Directory,
                    name='零度：[{0}]/{1}'.format(remark, name),
                    id=sid,
                    cover=cover,
                    description=description,
                    params={
                        'type': 'video',
                        'pf': 'ld'
                    },
                ))
        self.lditems =lditems

    def getSearch(self,url, header, cookie):
        yield requests.get(url, headers=header, cookies=cookie)

    def verifyCode(self, imgurl, resurl):
        retry = 10
        header = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"}
        while retry:
            try:
                session = requests.session()
                img = session.get(imgurl, headers=header).content
                code = session.post('https://api.nn.ci/ocr/b64/text', data=base64.b64encode(img).decode()).text
                res = session.post(url="{}{}".format(resurl,code), headers=header).json()
                if res["msg"] == "ok":
                    return session
            except Exception as e:
                print(e)
            finally:
                retry = retry - 1

    def _get_tk(self, url, params, ts):
        keys = []
        for key in params:
            keys.append(key)
        keys.sort()
        src = urlparse(url).path
        for key in keys:
            src += str(params[key])
        src += str(ts)
        src += 'XSpeUFjJ'
        return hashlib.md5(src.encode()).hexdigest()

    def proxy_m3u8(self, ctx, params):
        url = params['url']
        redirects = ''
        if '@@@' in url:
            infos = url.split('@@@')
            url = infos[0]
            redirects = infos[1]
        headers = params['headers'].copy()
        if redirects == 'False':
            r = requests.get(url, headers=headers, stream=True, verify=False, allow_redirects=False)
        else:
            r = requests.get(url, headers=headers, stream=True, verify=False)
        content_type = r.headers['Content-Type'] if 'Content-Type' in r.headers else ''
        if content_type.startswith('image/') or content_type.startswith('text/'):
            content_type = 'application/vnd.apple.mpegurl'
        r.headers['Content-Type'] = content_type
        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in ['connection', 'transfer-encoding']:
                    continue
                if content_type.lower() == 'application/vnd.apple.mpegurl':
                    if key.lower() in ['content-length', 'content-range']:
                        continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()
            if content_type.lower() == 'application/vnd.apple.mpegurl':
                for line in r.iter_lines(8192):
                    line = line.decode()
                    if len(line) > 0 and not line.startswith('#'):
                        if not line.startswith('http'):
                            if line.startswith('/'):
                                line = url[:url.index('/', 8)] + line
                            else:
                                line = url[:url.rindex('/') + 1] + line
                        line = get_proxy_url(
                            Spideryingshi.__name__,
                            self.proxy_ts.__name__,
                            {
                                'url': line,
                                'headers': params['headers'],
                            },
                        )
                    ctx.wfile.write((line + '\n').encode())
            else:
                for chunk in r.iter_content(8192):
                    ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

    def proxy_ts(self, ctx, params):
        url = params['url']
        headers = params['headers'].copy()
        for key in ctx.headers:
            if key.lower() in ['user-agent', 'host']:
                continue
            headers[key] = ctx.headers[key]
        r = requests.get(url, headers=headers, stream=True, verify=False)
        r.headers['Content-Type'] = 'video/MP2T'

        try:
            ctx.send_response(r.status_code)
            for key in r.headers:
                if key.lower() in ['connection', 'transfer-encoding', 'accept-ranges']:
                    continue
                ctx.send_header(key, r.headers[key])
            ctx.end_headers()
            stripped_image_header = False
            for chunk in r.iter_content(8192):
                if not stripped_image_header:
                    chunk = chunk.lstrip(b'\xFF\xD8\xFF\xE0\x00\x10\x4A\x46\x49\x46')
                    chunk = chunk.lstrip(b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')
                    chunk = chunk.lstrip(b'\x42\x4D\x5A\x27\x4C')
                    chunk = chunk.lstrip(b'\x42\x4D')
                    stripped_image_header = True
                ctx.wfile.write(chunk)
        except Exception as e:
            print(e)
        finally:
            try:
                r.close()
            except:
                pass

#if __name__ == '__main__':
    #spider = Spideryingshi()
    #res = spider.list_items(parent_item={'type': 'directory', 'id': '1216', 'name': '爱看：[更新至28集]/月歌行', 'cover': 'https://p3-bk.byteimg.com/tos-cn-i-mlhdmxsy5m/7635179d7e0444c39ec0e87cce9451a4~tplv-mlhdmxsy5m-q75:0:0.image', 'description': '少女柳梢为与神秘人三日相伴的欢愉，换走了自己一生的命运，从此历经波澜壮阔，随他一场悲欢离合。为守苍生...', 'cast': [], 'director': '', 'area': '', 'year': 2022, 'sources': [], 'danmakus': [], 'subtitles': [], 'params': {'type': 'video', 'pf': 'ik'}}, page=1)
    #res = spider.resolve_play_url({'playfrom': '', 'pf': 'ik', 'url': '1216-1-1'})
    #res = spider.search("黑暗荣耀")
    #print(res)